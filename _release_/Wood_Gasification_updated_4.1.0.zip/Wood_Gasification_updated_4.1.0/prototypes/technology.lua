data:extend({
  {
    type = "technology",
    name = "wood-gas-processing",
    icon = "__Wood_Gasification_updated__/graphics/technology/wood-gas-processing.png",
    icon_size = 256,
    prerequisites = {"oil-processing"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "wood-gasification",
      },
      {
        type = "unlock-recipe",
        recipe = "solid-fuel-from-tar"
      },
      -- {
      --   type = "unlock-recipe",
      --   recipe = "greenhouse"
      -- },
    },
    unit =
    {
      count = 100,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1}},
      time = 30
    },
    order = "d-b"
  },
  {
    type = "technology",
    name = "wood-gas-processing-to-crude-oil",
    icon = "__Wood_Gasification_updated__/graphics/technology/wood-gas-processing-to-crude-oil.png",
    icon_size = 256,
    prerequisites = {"wood-gas-processing"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "crude-oil-from-tar",
      },
    },
    unit =
    {
      count = 400,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1}
      },
      time = 30
    },
    order = "d-b"
  },
  {
    type = "technology",
    name = "advanced-wood-gas-processing",
    icon = "__Wood_Gasification_updated__/graphics/technology/advanced-wood-gas-processing.png",
    icon_size = 256,
    prerequisites = {"wood-gas-processing"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "advanced-wood-gasification",
      }
    },
    unit =
    {
      count = 150,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1}
      },
      time = 30
    },
    order = "d-b"
  },
  -- {
  --   type = "technology",
  --   name = "wood-seed-greenhouse",
  --   localised_name = {"", {"entity-name.E-greenhouse"}, " ", {"item-name.tree-seed"}},
  --   icon = "__space-age__/graphics/icons/tree-seed.png",
  --   icon_size = 64,
  --   essential = false,
  --   effects =
  --   {
  --     {
  --       type = "unlock-recipe",
  --       recipe = "wood-seed-greenhouse"
  --     }
  --   },
  --   prerequisites = {"agriculture"},
  --   research_trigger =
  --   {
  --     type = "mine-entity",
  --     entity = "dry-tree"
  --   }
  -- },
})

if mods["space-age"] and settings.startup["use-gleba"].value then
  table.insert( data.raw.technology["agriculture"].effects, { type = "unlock-recipe", recipe = "greenhouse" } )
  table.insert(data.raw.technology["tree-seeding"].effects, {type = "unlock-recipe", recipe = "wood-seed-greenhouse"})
  table.insert(data.raw.technology["yumako"].effects, {type = "unlock-recipe", recipe = "yumako-seed-greenhouse"})
  table.insert(data.raw.technology["jellynut"].effects, {type = "unlock-recipe", recipe = "jellynut-seed-greenhouse"})
else
  table.insert( data.raw.technology["wood-gas-processing"].effects, { type = "unlock-recipe", recipe = "greenhouse" })
  table.insert(data.raw.technology["tree-seeding"].effects, {type = "unlock-recipe", recipe = "wood-seed-greenhouse"})
end