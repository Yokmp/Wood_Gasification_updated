local hidden, default = true, false
if mods["space-age"] then
  default = true
  hidden = false
end
data:extend({
  {
    type = "bool-setting",
    name = "use-gleba",
    setting_type = "startup",
    default_value = default,
    order = "a",
    hidden = hidden
  },
})