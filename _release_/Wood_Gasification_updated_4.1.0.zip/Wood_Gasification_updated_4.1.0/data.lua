require("prototypes.entity")
require("prototypes.recipe")
require("prototypes.technology")
require("prototypes.item")


local t = data.raw.tree
for key, value in pairs(t) do
  if value.minable.result and value.minable.result == "wood" then
    value.minable = {
      mining_particle = "wooden-particle",
      mining_time = 0.5,
      results = {
        {type = "item", name = "wood", amount = 4},
        {type = "item", name = "tree-seed", amount = 1, probability = 0.1},
      }
    }
    -- log(serpent.block(value.name))
  end
end