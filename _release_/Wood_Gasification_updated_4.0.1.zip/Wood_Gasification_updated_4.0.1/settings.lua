local hidden = true
if mods["space-age"] then
  hidden = false
end
data:extend({
  {
    type = "bool-setting",
    name = "use-gleba",
    setting_type = "startup",
    default_value = false,
    order = "a",
    hidden = hidden
  },
})