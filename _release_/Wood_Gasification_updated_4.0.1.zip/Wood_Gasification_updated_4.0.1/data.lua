require("prototypes.entity")
require("prototypes.recipe")
require("prototypes.technology")
require("prototypes.item")

