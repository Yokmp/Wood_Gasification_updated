require("prototypes.entity")
require("prototypes.recipe")
require("prototypes.technology")
require("prototypes.item")

if mods["space-age"] and settings.startup["use-gleba"].value then
  table.insert( data.raw.technology["agriculture"].effects, { type = "unlock-recipe", recipe = "greenhouse" } )
else
  table.insert( data.raw.technology["wood-gas-processing"].effects, { type = "unlock-recipe", recipe = "greenhouse" })
end