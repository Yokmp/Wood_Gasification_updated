require("prototypes.entity")
require("prototypes.recipe")
require("prototypes.technology")
require("prototypes.item")

require("prototypes.space-age")
